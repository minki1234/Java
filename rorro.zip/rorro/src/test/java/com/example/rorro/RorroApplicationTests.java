package com.example.rorro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RorroApplicationTests {

	@Test
	void contextLoads() {
	}

}
